class Pipeline:
    pass