# base model
from .model import Model

# Setting the classical models 
# we implemented in the challenge
from .classical_models import LGBModel
from .classical_models import CatBoostModel