__version__ = '0.1.0'

__doc__="""
This is a package that is creat ed for the sae of the competition. 
It code written to support the pipeline used in our project
"""

SEED_NUMBER = 2052

from mlod.configurations import Config